# praise-animation

直播无限点赞动画，使用两种方式实现（CSS3,Canvas）

![image1](./images/bubble8.gif)